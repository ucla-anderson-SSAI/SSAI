const form = document.querySelector('#app-form');
const answer = document.querySelector('#answer');
const status = document.querySelector('#status');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  status.textContent = 'Calling Gemini...';
  answer.textContent = '';

  const data = Object.fromEntries(new FormData(form).entries());
  data.useKnowledgeBase = form.elements.useKnowledgeBase.checked;

  try {
    const response = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Request failed');

    status.textContent = `${result.model}${result.usedKnowledgeBase ? ' + docs' : ''}`;
    answer.textContent = result.answer;
  } catch (error) {
    status.textContent = 'Error';
    answer.textContent = error.message;
  }
});
